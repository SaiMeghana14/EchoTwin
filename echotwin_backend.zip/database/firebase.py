
def save_profile(profile: dict):
    return {"status":"saved","profile":profile}
