
from pydantic import BaseModel

class TwinProfile(BaseModel):
    name:str
    face_signature:int
    voice_signature:int
    writing_signature:int

class RiskResponse(BaseModel):
    risk_score:int
    threat_level:str
