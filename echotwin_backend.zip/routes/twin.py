
from fastapi import APIRouter
from agents.identity_builder import IdentityBuilder

router=APIRouter()

@router.post('/create')
def create_twin():
    return IdentityBuilder().build()
