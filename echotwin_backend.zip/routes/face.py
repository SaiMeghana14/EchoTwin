
from fastapi import APIRouter
from services.deepface_service import analyze_face

router=APIRouter()

@router.post('/analyze')
def face():
    return analyze_face()
