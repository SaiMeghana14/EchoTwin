
from fastapi import APIRouter
from services.speechbrain_service import analyze_voice

router=APIRouter()

@router.post('/analyze')
def voice():
    return analyze_voice()
