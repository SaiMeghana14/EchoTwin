
from fastapi import APIRouter
from services.writing_service import analyze_text

router=APIRouter()

@router.post('/analyze')
def writing(text:str='sample'):
    return analyze_text(text)
