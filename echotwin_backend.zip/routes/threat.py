
from fastapi import APIRouter
from services.threat_simulator import simulate

router=APIRouter()

@router.get('/simulate')
def threat():
    return simulate()
