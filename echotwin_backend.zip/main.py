
from fastapi import FastAPI
from routes.face import router as face_router
from routes.voice import router as voice_router
from routes.writing import router as writing_router
from routes.threat import router as threat_router
from routes.twin import router as twin_router

app = FastAPI(title="EchoTwin Backend")

app.include_router(twin_router, prefix="/twin")
app.include_router(face_router, prefix="/face")
app.include_router(voice_router, prefix="/voice")
app.include_router(writing_router, prefix="/writing")
app.include_router(threat_router, prefix="/threat")

@app.get("/")
def root():
    return {"message":"EchoTwin API Running"}
