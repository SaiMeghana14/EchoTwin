
def analyze_voice():
    return {"clone_probability":74,"authenticity":26}
