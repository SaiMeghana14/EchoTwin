
def analyze_face():
    return {"authenticity":84,"deepfake_probability":16}
