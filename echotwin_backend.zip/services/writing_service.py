
def analyze_text(text):
    return {"match_score":91,"impersonation_risk":"LOW"}
