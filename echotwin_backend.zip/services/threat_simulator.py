
def simulate():
    return {
        "voice_clone_risk":"HIGH",
        "face_risk":"MEDIUM",
        "writing_risk":"LOW"
    }
